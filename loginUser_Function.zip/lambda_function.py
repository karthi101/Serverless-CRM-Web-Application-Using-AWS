import json
import boto3
import hashlib
import jwt
import datetime

# Initialize DynamoDB (use the same region)
dynamodb = boto3.resource('dynamodb', region_name='sa-east-1')
table = dynamodb.Table('Users')

# Secret key for JWT (keep this private)
SECRET_KEY = "your-secret-key"

def lambda_handler(event, context):
    try:
        print("Incoming event:", event)
        
        body = json.loads(event.get('body', '{}'))
        email = body.get('email')
        password = body.get('password')

        if not email or not password:
            return {
                'statusCode': 400,
                'headers': {'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'error': 'Email and password are required'})
            }

        # Hash the entered password to match stored one
        hashed_pw = hashlib.sha256(password.encode()).hexdigest()

        # Check user in DynamoDB
        response = table.get_item(Key={'email': email})
        user = response.get('Item')

        if not user:
            return {
                'statusCode': 404,
                'headers': {'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'message': 'User not found'})
            }

        # Compare stored and entered password
        if user['password'] != hashed_pw:
            return {
                'statusCode': 401,
                'headers': {'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'message': 'Invalid password'})
            }

        # Generate JWT token (valid for 2 hours)
        payload = {
            'email': email,
            'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=2)
        }
        token = jwt.encode(payload, SECRET_KEY, algorithm='HS256')

        return {
            'statusCode': 200,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({'message': 'Login successful', 'token': token})
        }

    except Exception as e:
        print("Error:", str(e))
        return {
            'statusCode': 500,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({'error': str(e)})
        }
