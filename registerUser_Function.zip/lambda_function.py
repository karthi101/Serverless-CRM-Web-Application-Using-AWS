import json
import boto3
import hashlib

# Initialize DynamoDB (replace region if needed)
dynamodb = boto3.resource('dynamodb', region_name='sa-east-1')
table = dynamodb.Table('Users')  # must match your DynamoDB table name exactly

def lambda_handler(event, context):
    try:
        # Log input (for debugging in CloudWatch)
        print("Incoming event:", event)
        
        # Parse the incoming body (API Gateway sends it as string)
        body = json.loads(event.get('body', '{}'))

        # Extract fields
        email = body.get('email')
        password = body.get('password')

        if not email or not password:
            return {
                'statusCode': 400,
                'headers': {'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'error': 'Email and password are required'})
            }

        # Hash password for security
        hashed_pw = hashlib.sha256(password.encode()).hexdigest()

        # Save user to DynamoDB
        table.put_item(
            Item={
                'email': email,
                'password': hashed_pw
            }
        )

        # Return success
        return {
            'statusCode': 200,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({'message': 'User registered successfully'})
        }

    except Exception as e:
        print("Error:", str(e))
        return {
            'statusCode': 500,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({'error': str(e)})
        }
